﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace YouTubeDownloader
{
    public partial class MainForm : Form
    {
        private ConfigManager configManager;
        private DownloadManager downloadManager;
        private string currentDownloadStatus = "Ready";

        public MainForm()
        {
            InitializeComponent();
            configManager = new ConfigManager();
            downloadManager = new DownloadManager();
            LoadSettings();
        }

      

        // Controls
        private Label currentDownloadLabel;
        private Label authLabel;
        private TextBox urlTextBox;
        private ComboBox qualityComboBox;
        private CheckBox subtitlesCheckBox;
        private ComboBox toleranceComboBox;
        private RichTextBox logTextBox;

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Test authentication
            TestAuthentication();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveSettings();
        }

        private void LoadSettings()
        {
            try
            {
                outputTextBox.Text = configManager.LastDownloadPath;
                qualityComboBox.SelectedItem = configManager.DefaultQuality;
                subtitlesCheckBox.Checked = configManager.DownloadSubtitles;
                toleranceComboBox.SelectedItem = configManager.SizeTolerance.ToString("0.95");

                if (!string.IsNullOrEmpty(configManager.WindowGeometry))
                {
                    var size = configManager.WindowGeometry.Split('x');
                    if (size.Length == 2)
                    {
                        if (int.TryParse(size[0], out int width) && int.TryParse(size[1], out int height))
                        {
                            this.Size = new Size(width, height);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogMessage($"Error loading settings: {ex.Message}");
            }
        }

        private void SaveSettings()
        {
            try
            {
                configManager.LastDownloadPath = outputTextBox.Text;
                configManager.DefaultQuality = qualityComboBox.SelectedItem?.ToString() ?? "720p";
                configManager.DownloadSubtitles = subtitlesCheckBox.Checked;

                if (double.TryParse(toleranceComboBox.SelectedItem?.ToString(), out double tolerance))
                {
                    configManager.SizeTolerance = tolerance;
                }

                configManager.WindowGeometry = $"{this.Width}x{this.Height}";
                configManager.Save();
            }
            catch (Exception ex)
            {
                LogMessage($"Error saving settings: {ex.Message}");
            }
        }

        private void LogMessage(string message)
        {
            if (logTextBox.InvokeRequired)
            {
                logTextBox.Invoke(new Action<string>(LogMessage), message);
                return;
            }

            var timestamp = DateTime.Now.ToString("HH:mm:ss");
            logTextBox.AppendText($"[{timestamp}] {message}\n");
            logTextBox.ScrollToCaret();
        }

        private void UpdateCurrentDownload(string status)
        {
            if (currentDownloadLabel.InvokeRequired)
            {
                currentDownloadLabel.Invoke(new Action<string>(UpdateCurrentDownload), status);
                return;
            }

            currentDownloadLabel.Text = status;
            currentDownloadStatus = status;
        }

        //private void TestAuthentication()
        //{
        //    // This would test authentication - you'd need to implement actual authentication checking
        //    authLabel.Text = "🔍 Checking browser authentication...";

        //    Task.Run(() =>
        //    {
        //        // Simulate authentication check
        //        System.Threading.Thread.Sleep(1000);

        //        if (this.InvokeRequired)
        //        {
        //            this.Invoke(new Action(() =>
        //            {
        //                authLabel.Text = "✅ Authentication ready (using browser cookies if available)";
        //            }));
        //        }
        //    });
        //}
        private void TestAuthentication()
        {
            authLabel.Text = "🔍 Checking browser authentication...";

            Task.Run(() =>
            {
                if (CookieHelper.TryLoadChromeCookies(out var cookies))
                {
                    this.Invoke(new Action(() =>
                    {
                        authLabel.Text = "✅ Authentication successful (cookies loaded)";
                    }));
                }
                else
                {
                    this.Invoke(new Action(() =>
                    {
                        authLabel.Text = "❌ Failed to load cookies";
                    }));
                }
            });
        }
        // Event Handlers
        private void RefreshAuth_Click(object sender, EventArgs e)
        {
            TestAuthentication();
        }

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            using (var dialog = new FolderBrowserDialog())
            {
                dialog.SelectedPath = outputTextBox.Text;
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    outputTextBox.Text = dialog.SelectedPath;
                }
            }
        }

        private void QualityComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            configManager.DefaultQuality = qualityComboBox.SelectedItem?.ToString() ?? "720p";
        }

        private void SubtitlesCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            configManager.DownloadSubtitles = subtitlesCheckBox.Checked;
        }

        private void ToleranceComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (double.TryParse(toleranceComboBox.SelectedItem?.ToString(), out double tolerance))
            {
                configManager.SizeTolerance = tolerance;
            }
        }

        private void DownloadVideoButton_Click(object sender, EventArgs e)
        {
            string url = urlTextBox.Text.Trim();
            if (string.IsNullOrEmpty(url))
            {
                MessageBox.Show("Please enter a YouTube URL", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            UpdateCurrentDownload("Downloading video...");
            LogMessage($"Starting download: {url}");

            Task.Run(() =>
            {
                try
                {
                    // Here you would call your actual download logic
                    // For now, we'll simulate it
                    System.Threading.Thread.Sleep(2000);

                    this.Invoke(new Action(() =>
                    {
                        LogMessage("✅ Video download completed!");
                        UpdateCurrentDownload("Ready");
                    }));
                }
                catch (Exception ex)
                {
                    this.Invoke(new Action(() =>
                    {
                        LogMessage($"❌ Error: {ex.Message}");
                        UpdateCurrentDownload("Error");
                    }));
                }
            });
        }

        private void DownloadPlaylistButton_Click(object sender, EventArgs e)
        {
            string url = urlTextBox.Text.Trim();
            if (string.IsNullOrEmpty(url))
            {
                MessageBox.Show("Please enter a YouTube playlist URL", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            UpdateCurrentDownload("Downloading playlist...");
            LogMessage($"Starting playlist download: {url}");

            Task.Run(() =>
            {
                try
                {
                    // Simulate playlist download
                    for (int i = 1; i <= 5; i++)
                    {
                        this.Invoke(new Action(() =>
                        {
                            LogMessage($"📥 Downloading video {i}/5");
                        }));
                        System.Threading.Thread.Sleep(1000);
                    }

                    this.Invoke(new Action(() =>
                    {
                        LogMessage("✅ Playlist download completed!");
                        UpdateCurrentDownload("Ready");
                    }));
                }
                catch (Exception ex)
                {
                    this.Invoke(new Action(() =>
                    {
                        LogMessage($"❌ Error: {ex.Message}");
                        UpdateCurrentDownload("Error");
                    }));
                }
            });
        }

        private void BatchDownloadButton_Click(object sender, EventArgs e)
        {
            using (var dialog = new OpenFileDialog())
            {
                dialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                dialog.Title = "Select URLs file";

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    configManager.LastPlaylistFile = dialog.FileName;

                    Task.Run(() =>
                    {
                        try
                        {
                            var urls = File.ReadAllLines(dialog.FileName)
                                         .Where(line => !string.IsNullOrWhiteSpace(line) && !line.StartsWith("#"))
                                         .ToList();

                            this.Invoke(new Action(() =>
                            {
                                LogMessage($"📋 Processing {urls.Count} URLs...");
                                UpdateCurrentDownload($"Batch download: 0/{urls.Count}");
                            }));

                            for (int i = 0; i < urls.Count; i++)
                            {
                                string url = urls[i];
                                this.Invoke(new Action(() =>
                                {
                                    LogMessage($"\n📥 Downloading {i + 1}/{urls.Count}: {url}");
                                    UpdateCurrentDownload($"Batch download: {i + 1}/{urls.Count}");
                                }));

                                // Simulate download
                                System.Threading.Thread.Sleep(1500);
                            }

                            this.Invoke(new Action(() =>
                            {
                                LogMessage("🎉 Batch download completed!");
                                UpdateCurrentDownload("Ready");
                            }));
                        }
                        catch (Exception ex)
                        {
                            this.Invoke(new Action(() =>
                            {
                                LogMessage($"❌ Batch download error: {ex.Message}");
                                UpdateCurrentDownload("Error");
                            }));
                        }
                    });
                }
            }
        }

        private void ResumeButton_Click(object sender, EventArgs e)
        {
            UpdateCurrentDownload("Resuming failed downloads...");
            LogMessage("🔄 Checking for failed downloads to resume...");

            Task.Run(() =>
            {
                try
                {
                    // Simulate resume
                    System.Threading.Thread.Sleep(2000);

                    this.Invoke(new Action(() =>
                    {
                        LogMessage("✅ Resume completed!");
                        UpdateCurrentDownload("Ready");
                    }));
                }
                catch (Exception ex)
                {
                    this.Invoke(new Action(() =>
                    {
                        LogMessage($"❌ Resume error: {ex.Message}");
                        UpdateCurrentDownload("Error");
                    }));
                }
            });
        }

        private void AboutButton_Click(object sender, EventArgs e)
        {
            var aboutForm = new AboutForm();
            aboutForm.ShowDialog();
        }

        private void ClearLogButton_Click(object sender, EventArgs e)
        {
            logTextBox.Clear();
        }
    }
}