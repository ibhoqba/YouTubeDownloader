﻿using System;
using System.Data.SQLite;
using System.IO;
using System.Security.Cryptography;
using System.Text;
namespace YouTubeDownloader
{


    public class CookieHelper
    {
        public static bool TryLoadChromeCookies(out Dictionary<string, string> cookies)
        {
            cookies = new Dictionary<string, string>();

            try
            {
                string chromeCookiesPath = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    @"Google\Chrome\User Data\Default\Cookies");

                if (!File.Exists(chromeCookiesPath))
                    return false;

                using (var conn = new SQLiteConnection($"Data Source={chromeCookiesPath};"))
                {
                    conn.Open();
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = "SELECT name, encrypted_value FROM cookies WHERE host_key LIKE '%youtube.com%'";
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string name = reader.GetString(0);
                                byte[] encrypted = (byte[])reader["encrypted_value"];

                                // Decrypt with DPAPI
                                byte[] decrypted = ProtectedData.Unprotect(encrypted, null, DataProtectionScope.CurrentUser);
                                string value = Encoding.UTF8.GetString(decrypted);

                                cookies[name] = value;
                            }
                        }
                    }
                }

                // If we got at least one cookie, success
                return cookies.Count > 0;
            }
            catch
            {
                return false;
            }
        }
    }
}
