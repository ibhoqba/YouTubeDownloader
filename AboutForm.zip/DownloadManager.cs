﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace YouTubeDownloader
{
    public class DownloadManager
    {
        private string stateFile;
        private Dictionary<string, DownloadState> downloadState;

        public DownloadManager()
        {
            stateFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "download_state.json");
            downloadState = LoadState();
        }

        private Dictionary<string, DownloadState> LoadState()
        {
            try
            {
                if (File.Exists(stateFile))
                {
                    string json = File.ReadAllText(stateFile);
                    return JsonSerializer.Deserialize<Dictionary<string, DownloadState>>(json);
                }
            }
            catch
            {
                // If loading fails, return empty dictionary
            }

            return new Dictionary<string, DownloadState>();
        }

        public void SaveState()
        {
            try
            {
                string json = JsonSerializer.Serialize(downloadState, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(stateFile, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"State save error: {ex.Message}");
            }
        }

        public void UpdateDownloadState(string url, string status, double progress = 0, int retryCount = 0,
                                       long expectedSize = 0, long downloadedSize = 0, string quality = "")
        {
            downloadState[url] = new DownloadState
            {
                Status = status,
                Progress = progress,
                RetryCount = retryCount,
                ExpectedSize = expectedSize,
                DownloadedSize = downloadedSize,
                Quality = quality,
                LastUpdated = DateTime.Now,
                Timestamp = DateTimeOffset.Now.ToUnixTimeSeconds()
            };
            SaveState();
        }

        public void ClearState(string url)
        {
            if (downloadState.ContainsKey(url))
            {
                downloadState.Remove(url);
                SaveState();
            }
        }

        public List<string> GetFailedDownloads()
        {
            var failed = new List<string>();
            foreach (var kvp in downloadState)
            {
                if (kvp.Value.Status == "error" || kvp.Value.Status == "retrying")
                {
                    failed.Add(kvp.Key);
                }
            }
            return failed;
        }

        public List<string> GetIncompleteDownloads()
        {
            var incomplete = new List<string>();
            foreach (var kvp in downloadState)
            {
                if (kvp.Value.Status == "downloading" && kvp.Value.Progress < 95)
                {
                    incomplete.Add(kvp.Key);
                }
            }
            return incomplete;
        }

        private class DownloadState
        {
            public string Status { get; set; }
            public double Progress { get; set; }
            public int RetryCount { get; set; }
            public long ExpectedSize { get; set; }
            public long DownloadedSize { get; set; }
            public string Quality { get; set; }
            public DateTime LastUpdated { get; set; }
            public long Timestamp { get; set; }
        }
    }
}