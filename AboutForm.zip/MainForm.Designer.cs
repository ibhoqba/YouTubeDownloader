﻿namespace YouTubeDownloader
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            mainPanel = new TableLayoutPanel();
            currentDownloadPanel = new GroupBox();
            currentDownloadLabel = new Label();
            authPanel = new GroupBox();
            authFlowPanel = new FlowLayoutPanel();
            authLabel = new Label();
            refreshAuthButton = new Button();
            optionsPanel = new GroupBox();
            groupBox1 = new GroupBox();
            qualityComboBox = new ComboBox();
            subtitlesCheckBox = new CheckBox();
            toleranceComboBox = new ComboBox();
            skipLabel = new Label();
            logTextBox = new RichTextBox();
            logLabel = new Label();
            actionPanel = new FlowLayoutPanel();
            downloadVideoButton = new Button();
            downloadPlaylistButton = new Button();
            batchDownloadButton = new Button();
            resumeButton = new Button();
            clearLogButton = new Button();
            aboutButton = new Button();
            groupBox2 = new GroupBox();
            urlTextBox = new TextBox();
            outputTextBox = new TextBox();
            browseButton = new Button();
            mainPanel.SuspendLayout();
            currentDownloadPanel.SuspendLayout();
            authPanel.SuspendLayout();
            authFlowPanel.SuspendLayout();
            optionsPanel.SuspendLayout();
            groupBox1.SuspendLayout();
            actionPanel.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // mainPanel
            // 
            mainPanel.ColumnCount = 1;
            mainPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            mainPanel.Controls.Add(currentDownloadPanel, 0, 0);
            mainPanel.Controls.Add(authPanel, 0, 1);
            mainPanel.Controls.Add(optionsPanel, 0, 5);
            mainPanel.Controls.Add(logTextBox, 0, 9);
            mainPanel.Controls.Add(logLabel, 0, 7);
            mainPanel.Controls.Add(actionPanel, 0, 6);
            mainPanel.Controls.Add(groupBox2, 0, 3);
            mainPanel.Dock = DockStyle.Fill;
            mainPanel.Location = new Point(0, 0);
            mainPanel.Name = "mainPanel";
            mainPanel.Padding = new Padding(10);
            mainPanel.RowCount = 10;
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 60F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 63F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 17F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 62F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 8F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 82F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 43F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 33F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 13F));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            mainPanel.Size = new Size(1004, 590);
            mainPanel.TabIndex = 0;
            // 
            // currentDownloadPanel
            // 
            currentDownloadPanel.Controls.Add(currentDownloadLabel);
            currentDownloadPanel.Dock = DockStyle.Fill;
            currentDownloadPanel.Location = new Point(13, 13);
            currentDownloadPanel.Name = "currentDownloadPanel";
            currentDownloadPanel.Padding = new Padding(5);
            currentDownloadPanel.Size = new Size(978, 54);
            currentDownloadPanel.TabIndex = 0;
            currentDownloadPanel.TabStop = false;
            currentDownloadPanel.Text = "Current Download";
            // 
            // currentDownloadLabel
            // 
            currentDownloadLabel.Dock = DockStyle.Fill;
            currentDownloadLabel.Font = new Font("Arial", 10F, FontStyle.Bold);
            currentDownloadLabel.ForeColor = Color.Blue;
            currentDownloadLabel.Location = new Point(5, 21);
            currentDownloadLabel.Name = "currentDownloadLabel";
            currentDownloadLabel.Size = new Size(968, 28);
            currentDownloadLabel.TabIndex = 0;
            // 
            // authPanel
            // 
            authPanel.Controls.Add(authFlowPanel);
            authPanel.Dock = DockStyle.Fill;
            authPanel.Location = new Point(13, 73);
            authPanel.Name = "authPanel";
            authPanel.Padding = new Padding(5);
            authPanel.Size = new Size(978, 57);
            authPanel.TabIndex = 1;
            authPanel.TabStop = false;
            authPanel.Text = "Authentication Status";
            // 
            // authFlowPanel
            // 
            authFlowPanel.Controls.Add(authLabel);
            authFlowPanel.Controls.Add(refreshAuthButton);
            authFlowPanel.Dock = DockStyle.Fill;
            authFlowPanel.Location = new Point(5, 21);
            authFlowPanel.Name = "authFlowPanel";
            authFlowPanel.Size = new Size(968, 31);
            authFlowPanel.TabIndex = 0;
            // 
            // authLabel
            // 
            authLabel.AutoSize = true;
            authLabel.Location = new Point(3, 0);
            authLabel.Name = "authLabel";
            authLabel.Size = new Size(206, 15);
            authLabel.TabIndex = 0;
            authLabel.Text = "🔍 Checking browser authentication...";
            // 
            // refreshAuthButton
            // 
            refreshAuthButton.Location = new Point(215, 3);
            refreshAuthButton.Name = "refreshAuthButton";
            refreshAuthButton.Size = new Size(100, 25);
            refreshAuthButton.TabIndex = 1;
            refreshAuthButton.Text = "Refresh Auth";
            refreshAuthButton.Click += RefreshAuth_Click;
            // 
            // optionsPanel
            // 
            optionsPanel.Controls.Add(groupBox1);
            optionsPanel.Dock = DockStyle.Fill;
            optionsPanel.Location = new Point(13, 223);
            optionsPanel.Name = "optionsPanel";
            optionsPanel.Size = new Size(978, 76);
            optionsPanel.TabIndex = 5;
            optionsPanel.TabStop = false;
            optionsPanel.Text = "Options";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(qualityComboBox);
            groupBox1.Controls.Add(subtitlesCheckBox);
            groupBox1.Controls.Add(toleranceComboBox);
            groupBox1.Controls.Add(skipLabel);
            groupBox1.Dock = DockStyle.Fill;
            groupBox1.Location = new Point(3, 19);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(972, 54);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            // 
            // qualityComboBox
            // 
            qualityComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            qualityComboBox.Items.AddRange(new object[] { "Best", "1080p", "720p", "480p", "Audio" });
            qualityComboBox.Location = new Point(541, 14);
            qualityComboBox.Name = "qualityComboBox";
            qualityComboBox.Size = new Size(121, 23);
            qualityComboBox.TabIndex = 0;
            qualityComboBox.Tag = "الجودة";
            qualityComboBox.SelectedIndexChanged += QualityComboBox_SelectedIndexChanged;
            // 
            // subtitlesCheckBox
            // 
            subtitlesCheckBox.AutoSize = true;
            subtitlesCheckBox.Location = new Point(267, 18);
            subtitlesCheckBox.Name = "subtitlesCheckBox";
            subtitlesCheckBox.Size = new Size(128, 19);
            subtitlesCheckBox.TabIndex = 0;
            subtitlesCheckBox.Text = "Download Subtitles";
            subtitlesCheckBox.CheckedChanged += SubtitlesCheckBox_CheckedChanged;
            // 
            // toleranceComboBox
            // 
            toleranceComboBox.Items.AddRange(new object[] { "0.8", "0.85", "0.9", "0.95" });
            toleranceComboBox.Location = new Point(84, 16);
            toleranceComboBox.Name = "toleranceComboBox";
            toleranceComboBox.Size = new Size(121, 23);
            toleranceComboBox.TabIndex = 2;
            toleranceComboBox.SelectedIndexChanged += ToleranceComboBox_SelectedIndexChanged;
            // 
            // skipLabel
            // 
            skipLabel.AutoSize = true;
            skipLabel.Location = new Point(6, 24);
            skipLabel.Name = "skipLabel";
            skipLabel.Size = new Size(72, 15);
            skipLabel.TabIndex = 1;
            skipLabel.Text = "Skip if file is:";
            // 
            // logTextBox
            // 
            logTextBox.Dock = DockStyle.Fill;
            logTextBox.Font = new Font("Consolas", 9F);
            logTextBox.Location = new Point(13, 394);
            logTextBox.Name = "logTextBox";
            logTextBox.ReadOnly = true;
            logTextBox.Size = new Size(978, 183);
            logTextBox.TabIndex = 9;
            logTextBox.Text = "";
            // 
            // logLabel
            // 
            logLabel.AutoSize = true;
            logLabel.Location = new Point(13, 345);
            logLabel.Name = "logLabel";
            logLabel.Size = new Size(87, 15);
            logLabel.TabIndex = 8;
            logLabel.Text = "Download Log:";
            // 
            // actionPanel
            // 
            actionPanel.Controls.Add(downloadVideoButton);
            actionPanel.Controls.Add(downloadPlaylistButton);
            actionPanel.Controls.Add(batchDownloadButton);
            actionPanel.Controls.Add(resumeButton);
            actionPanel.Controls.Add(clearLogButton);
            actionPanel.Controls.Add(aboutButton);
            actionPanel.Location = new Point(13, 305);
            actionPanel.Name = "actionPanel";
            actionPanel.Size = new Size(978, 37);
            actionPanel.TabIndex = 6;
            // 
            // downloadVideoButton
            // 
            downloadVideoButton.Location = new Point(3, 3);
            downloadVideoButton.Name = "downloadVideoButton";
            downloadVideoButton.Size = new Size(150, 35);
            downloadVideoButton.TabIndex = 0;
            downloadVideoButton.Text = "⬇️ Download Video";
            downloadVideoButton.Click += DownloadVideoButton_Click;
            // 
            // downloadPlaylistButton
            // 
            downloadPlaylistButton.Location = new Point(159, 3);
            downloadPlaylistButton.Name = "downloadPlaylistButton";
            downloadPlaylistButton.Size = new Size(150, 35);
            downloadPlaylistButton.TabIndex = 1;
            downloadPlaylistButton.Text = "📁 Download Playlist";
            downloadPlaylistButton.Click += DownloadPlaylistButton_Click;
            // 
            // batchDownloadButton
            // 
            batchDownloadButton.Location = new Point(315, 3);
            batchDownloadButton.Name = "batchDownloadButton";
            batchDownloadButton.Size = new Size(150, 35);
            batchDownloadButton.TabIndex = 2;
            batchDownloadButton.Text = "📋 Batch Download";
            batchDownloadButton.Click += BatchDownloadButton_Click;
            // 
            // resumeButton
            // 
            resumeButton.Location = new Point(471, 3);
            resumeButton.Name = "resumeButton";
            resumeButton.Size = new Size(150, 35);
            resumeButton.TabIndex = 3;
            resumeButton.Text = "🔄 Resume Failed";
            resumeButton.Click += ResumeButton_Click;
            // 
            // clearLogButton
            // 
            clearLogButton.Location = new Point(627, 3);
            clearLogButton.Name = "clearLogButton";
            clearLogButton.Size = new Size(120, 35);
            clearLogButton.TabIndex = 1;
            clearLogButton.Text = "\U0001f9f9 Clear Log";
            clearLogButton.Click += ClearLogButton_Click;
            // 
            // aboutButton
            // 
            aboutButton.Location = new Point(753, 3);
            aboutButton.Name = "aboutButton";
            aboutButton.Size = new Size(120, 35);
            aboutButton.TabIndex = 0;
            aboutButton.Text = "👤 About Me";
            aboutButton.Click += AboutButton_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(urlTextBox);
            groupBox2.Controls.Add(outputTextBox);
            groupBox2.Controls.Add(browseButton);
            groupBox2.Dock = DockStyle.Fill;
            groupBox2.Location = new Point(13, 153);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(978, 56);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "الجودة";
            // 
            // urlTextBox
            // 
            urlTextBox.Location = new Point(147, 24);
            urlTextBox.Name = "urlTextBox";
            urlTextBox.Size = new Size(611, 23);
            urlTextBox.TabIndex = 1;
            // 
            // outputTextBox
            // 
            outputTextBox.Location = new Point(9, 22);
            outputTextBox.Name = "outputTextBox";
            outputTextBox.Size = new Size(112, 23);
            outputTextBox.TabIndex = 1;
            // 
            // browseButton
            // 
            browseButton.Location = new Point(783, 22);
            browseButton.Name = "browseButton";
            browseButton.Size = new Size(66, 23);
            browseButton.TabIndex = 2;
            browseButton.Text = "Browse";
            browseButton.Click += BrowseButton_Click;
            // 
            // MainForm
            // 
            ClientSize = new Size(1004, 590);
            Controls.Add(mainPanel);
            Name = "MainForm";
            FormClosing += MainForm_FormClosing;
            Load += MainForm_Load;
            mainPanel.ResumeLayout(false);
            mainPanel.PerformLayout();
            currentDownloadPanel.ResumeLayout(false);
            authPanel.ResumeLayout(false);
            authFlowPanel.ResumeLayout(false);
            authFlowPanel.PerformLayout();
            optionsPanel.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            actionPanel.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel mainPanel;
        private GroupBox currentDownloadPanel;
        private GroupBox authPanel;
        private FlowLayoutPanel authFlowPanel;
        private Button refreshAuthButton;
        private Button browseButton;
        private GroupBox optionsPanel;
        private Label skipLabel;
        private FlowLayoutPanel actionPanel;
        private Button downloadVideoButton;
        private Button downloadPlaylistButton;
        private Button batchDownloadButton;
        private Button resumeButton;
        private Button aboutButton;
        private Button clearLogButton;
        private Label logLabel;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private TextBox outputTextBox;
    }
}
