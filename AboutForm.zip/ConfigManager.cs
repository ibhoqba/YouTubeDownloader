﻿using System;
using System.IO;
using System.Text.Json;

namespace YouTubeDownloader
{
    public class ConfigManager
    {
        private string configFile;
        private ConfigData configData;

        public string LastDownloadPath
        {
            get => configData.LastDownloadPath;
            set => configData.LastDownloadPath = value;
        }

        public string LastPlaylistFile
        {
            get => configData.LastPlaylistFile;
            set => configData.LastPlaylistFile = value;
        }

        public string DefaultQuality
        {
            get => configData.DefaultQuality;
            set => configData.DefaultQuality = value;
        }

        public double SizeTolerance
        {
            get => configData.SizeTolerance;
            set => configData.SizeTolerance = value;
        }

        public bool DownloadSubtitles
        {
            get => configData.DownloadSubtitles;
            set => configData.DownloadSubtitles = value;
        }

        public string WindowGeometry
        {
            get => configData.WindowGeometry;
            set => configData.WindowGeometry = value;
        }

        public ConfigManager()
        {
            configFile = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "config.json");
            Load();
        }

        private void Load()
        {
            try
            {
                if (File.Exists(configFile))
                {
                    string json = File.ReadAllText(configFile);
                    configData = JsonSerializer.Deserialize<ConfigData>(json);
                }
                else
                {
                    configData = new ConfigData();
                }
            }
            catch
            {
                configData = new ConfigData();
            }
        }

        public void Save()
        {
            try
            {
                string json = JsonSerializer.Serialize(configData, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(configFile, json);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Config save error: {ex.Message}");
            }
        }

        private class ConfigData
        {
            public string LastDownloadPath { get; set; } = "downloads";
            public string LastPlaylistFile { get; set; } = "";
            public string DefaultQuality { get; set; } = "720p";
            public double SizeTolerance { get; set; } = 0.9;
            public bool DownloadSubtitles { get; set; } = false;
            public string WindowGeometry { get; set; } = "800x700";
        }
    }
}